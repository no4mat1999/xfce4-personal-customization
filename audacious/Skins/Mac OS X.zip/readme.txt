 ________________________________________

  Mac OS X v1.0 - By DeeLight
 ________________________________________

  I wanted my Winamp X skin to look even more like
  the Aqua interface of Mac OS X. Now, most of the
  elements should look like the OS and only a few
  are different. All credits should go to Apple who
  created this amazing Operating System.
 ________________________________________

  Please make any comments or any suggestion to
  make this skin look better, by keeping the Aqua
  interface. To contact me, send and e-Mail to
  deelight@flashmail.com
 ________________________________________

  You can also visit my Home Page at:
  http://deelight.quadrent.net/
 ________________________________________